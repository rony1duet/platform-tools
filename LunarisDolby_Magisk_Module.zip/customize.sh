ui_print "**************************************************"
ui_print "           Lunaris Dolby Atmos Module             "
ui_print "       Maintained by MD RONY HOSSEN (rony1duet)   "
ui_print "**************************************************"

ui_print "- Disabling stock co.aospa.dolby..."
pm disable-user --user 0 co.aospa.dolby >/dev/null 2>&1 || true
pm uninstall -k --user 0 co.aospa.dolby >/dev/null 2>&1 || true
pm disable-user --user 0 co.aospa.dolby.auto_generated_rro_product__ >/dev/null 2>&1 || true
pm uninstall -k --user 0 co.aospa.dolby.auto_generated_rro_product__ >/dev/null 2>&1 || true

ui_print "- Masking stock DolbyManager app & overlay..."
mkdir -p $MODPATH/system/system_ext/priv-app/DolbyManager
touch $MODPATH/system/system_ext/priv-app/DolbyManager/.replace
mkdir -p $MODPATH/system/product/overlay/DolbyManager__custom_sweet2__auto_generated_rro_product
touch $MODPATH/system/product/overlay/DolbyManager__custom_sweet2__auto_generated_rro_product/.replace

ui_print "- Setting module file permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk 0 0 0644
set_perm $MODPATH/system/product/overlay/DolbyFrameworksResCommon.apk 0 0 0644

# Register and install Lunaris Dolby Atmos in PackageManager if system is running
APK_CAND=""
for cand in "$MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk" "$MODPATH/system_ext/priv-app/LunarisDolby/LunarisDolby.apk" "$MODPATH/common/LunarisDolby.apk"; do
  if [ -f "$cand" ]; then
    APK_CAND="$cand"
    break
  fi
done

if [ -n "$APK_CAND" ]; then
  if [ "$(getprop sys.boot_completed)" = "1" ] || (command -v pm >/dev/null 2>&1 && pm path android >/dev/null 2>&1); then
    ui_print "- Registering Lunaris Dolby Atmos APK in PackageManager..."
    pm install -r -d -g "$APK_CAND" >/dev/null 2>&1 || pm install -r "$APK_CAND" >/dev/null 2>&1 || true
    pm grant org.lunaris.dolby android.permission.MODIFY_AUDIO_ROUTING >/dev/null 2>&1 || true
    pm grant org.lunaris.dolby android.permission.RECORD_AUDIO >/dev/null 2>&1 || true
    appops set org.lunaris.dolby GET_USAGE_STATS allow >/dev/null 2>&1 || true
    ui_print "- Lunaris Dolby Atmos APK installed and permissions granted!"
  else
    ui_print "- Note: APK staged and will be finalized on next boot by service.sh"
  fi
fi

ui_print "- Verifying installation..."
if [ -f $MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk ]; then
  ui_print "- LunarisDolby APK staged successfully in module!"
fi

ui_print "- Installation complete! Please reboot your device to apply system audio mounts."
