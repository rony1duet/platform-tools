ui_print "**************************************************"
ui_print "           Lunaris Dolby Atmos Module             "
ui_print "       Maintained by rony1duet (MD RONY)          "
ui_print "**************************************************"

ui_print "- Removing stock co.aospa.dolby..."
pm disable-user --user 0 co.aospa.dolby >/dev/null 2>&1
pm uninstall -k --user 0 co.aospa.dolby >/dev/null 2>&1
pm disable-user --user 0 co.aospa.dolby.auto_generated_rro_product__ >/dev/null 2>&1
pm uninstall -k --user 0 co.aospa.dolby.auto_generated_rro_product__ >/dev/null 2>&1

ui_print "- Installing Lunaris Dolby Atmos..."
mkdir -p $MODPATH/system/system_ext/priv-app/DolbyManager
touch $MODPATH/system/system_ext/priv-app/DolbyManager/.replace
mkdir -p $MODPATH/system/product/overlay/DolbyManager__custom_sweet2__auto_generated_rro_product
touch $MODPATH/system/product/overlay/DolbyManager__custom_sweet2__auto_generated_rro_product/.replace

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk 0 0 0644
set_perm $MODPATH/system/product/overlay/DolbyFrameworksResCommon.apk 0 0 0644

ui_print "- Verifying installation..."
if [ -f $MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk ]; then
  ui_print "- LunarisDolby APK staged successfully!"
fi

ui_print "- Installation complete! Please reboot your device to apply system mounts."
