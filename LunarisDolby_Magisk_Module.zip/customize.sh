ui_print "**************************************************"
ui_print "           Lunaris Dolby Atmos Module             "
ui_print "       Maintained by rony1duet (MD RONY)          "
ui_print "**************************************************"

ui_print "- Installing Lunaris Dolby Atmos..."

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk 0 0 0644
set_perm $MODPATH/system/product/overlay/DolbyFrameworksResCommon.apk 0 0 0644

ui_print "- Verifying installation..."
if [ -f $MODPATH/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk ]; then
  ui_print "- LunarisDolby APK staged successfully!"
fi

ui_print "- Installation complete! Please reboot your device."
