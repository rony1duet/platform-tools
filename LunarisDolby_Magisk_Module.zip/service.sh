#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

# Ensure stock co.aospa.dolby is disabled
pm disable-user --user 0 co.aospa.dolby >/dev/null 2>&1
pm disable-user --user 0 co.aospa.dolby.auto_generated_rro_product__ >/dev/null 2>&1

# Ensure LunarisDolby permissions and appops
pm grant org.lunaris.dolby android.permission.MODIFY_AUDIO_ROUTING >/dev/null 2>&1
pm grant org.lunaris.dolby android.permission.RECORD_AUDIO >/dev/null 2>&1
appops set org.lunaris.dolby GET_USAGE_STATS allow >/dev/null 2>&1
