#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

# Ensure stock co.aospa.dolby remains suppressed
pm disable-user --user 0 co.aospa.dolby >/dev/null 2>&1 || true
pm disable-user --user 0 co.aospa.dolby.auto_generated_rro_product__ >/dev/null 2>&1 || true

# Install LunarisDolby APK if missing (e.g. flashed in recovery or uninstalled)
if ! pm path org.lunaris.dolby >/dev/null 2>&1; then
  APK_CAND=""
  if [ -f "$MODDIR/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk" ]; then
    APK_CAND="$MODDIR/system/system_ext/priv-app/LunarisDolby/LunarisDolby.apk"
  elif [ -f "$MODDIR/system_ext/priv-app/LunarisDolby/LunarisDolby.apk" ]; then
    APK_CAND="$MODDIR/system_ext/priv-app/LunarisDolby/LunarisDolby.apk"
  elif [ -f "$MODDIR/common/LunarisDolby.apk" ]; then
    APK_CAND="$MODDIR/common/LunarisDolby.apk"
  fi
  if [ -n "$APK_CAND" ]; then
    pm install -r -d -g "$APK_CAND" >/dev/null 2>&1 || pm install -r "$APK_CAND" >/dev/null 2>&1 || true
  fi
fi

# Ensure LunarisDolby permissions and appops
pm grant org.lunaris.dolby android.permission.MODIFY_AUDIO_ROUTING >/dev/null 2>&1 || true
pm grant org.lunaris.dolby android.permission.RECORD_AUDIO >/dev/null 2>&1 || true
appops set org.lunaris.dolby GET_USAGE_STATS allow >/dev/null 2>&1 || true
