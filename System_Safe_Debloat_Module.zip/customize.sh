ui_print "**************************************************"
ui_print "       System Safe Debloat KernelSU Module        "
ui_print "       Maintained by Md Rony Hossen (rony1duet)   "
ui_print "**************************************************"

ui_print "- Disabling and uninstalling debloated packages..."
pm disable-user --user 0 com.google.android.apps.safetyhub >/dev/null 2>&1
pm uninstall -k --user 0 com.google.android.apps.safetyhub >/dev/null 2>&1
pm disable-user --user 0 com.google.android.apps.accessibility.voiceaccess >/dev/null 2>&1
pm uninstall -k --user 0 com.google.android.apps.accessibility.voiceaccess >/dev/null 2>&1
pm disable-user --user 0 com.google.android.apps.recorder >/dev/null 2>&1
pm uninstall -k --user 0 com.google.android.apps.recorder >/dev/null 2>&1
pm disable-user --user 0 org.omnirom.omnijaws >/dev/null 2>&1
pm uninstall -k --user 0 org.omnirom.omnijaws >/dev/null 2>&1

ui_print "- Setting module permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644

ui_print "- System Safe Debloat installed successfully!"
ui_print "- Please reboot your device to apply full system mounts."
