#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

# Ensure debloated apps remain suppressed across system updates
pm disable-user --user 0 com.google.android.apps.safetyhub >/dev/null 2>&1
pm disable-user --user 0 com.google.android.apps.accessibility.voiceaccess >/dev/null 2>&1
pm disable-user --user 0 com.google.android.apps.recorder >/dev/null 2>&1
pm disable-user --user 0 org.omnirom.omnijaws >/dev/null 2>&1
